#pragma once
#include <iostream>
#include "ram.hpp"

constexpr int CALLSTACK_SIZE{512};

class vm
{
private:
public:
	char A;
	char B;
	char E;
	int AX;
	int BX;
	int EX;
	int DA;
	int DB;

	int IP;
	bool CP;
	int SP;
	int HP;
	int BP;


};