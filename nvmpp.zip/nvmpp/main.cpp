#include "vm.hpp"

int main()
{
	return 0;
}